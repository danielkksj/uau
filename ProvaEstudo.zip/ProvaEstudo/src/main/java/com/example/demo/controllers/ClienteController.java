package com.example.demo.controllers;


import com.example.demo.models.ClienteModel;
import com.example.demo.models.Erro;
import com.example.demo.services.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController()
@RequestMapping("/apis")
public class ClienteController {

    @Autowired
    ClienteService clienteService;

    @GetMapping("/info")
    public ResponseEntity info() {
        if(clienteService.testaConexao()) {
            return ResponseEntity.ok("Mongo conectado, Nickolas Antunes 102419957");
        }
        return ResponseEntity.internalServerError().body("Mongo falhou");
    }

    @GetMapping("/find-by-pais/{pais}")
    public ResponseEntity<Object> findByPais(@PathVariable String pais) {
        List<ClienteModel> clienteModels = clienteService.findByPais(pais);

        if(clienteModels.isEmpty()) {
            return ResponseEntity.badRequest().body(new Erro("Erro pais", "Nenhum pais encontrado"));
        }
        return ResponseEntity.ok(clienteModels);
    }

    @GetMapping("/find-by-id/")
    public ResponseEntity<Object> findById(@RequestParam("id") int id) {
        ClienteModel cliente = clienteService.findById(id);

        if(cliente != null)
            return ResponseEntity.ok().body(cliente);
        return ResponseEntity.badRequest().body((new Erro("Erro cliente", "Nenhum cliente encontrado")  ));
    }

    @GetMapping("/find-by-name/{name}")
    public ResponseEntity<Object> findByName(@PathVariable String name) {
        List<ClienteModel> clientes = clienteService.findByName(name);

        if(clientes.isEmpty())
            return ResponseEntity.badRequest().body((new Erro("Erro cliente", "Nenhum cliente encontrado")));
        return ResponseEntity.ok().body(clientes);
    }

    @GetMapping("/get-paises")
    public ResponseEntity<Object> getPaises() {
        List<String> paises = clienteService.listarPaisesEmOrdem();

        return ResponseEntity.ok().body(paises);
    }

    @PostMapping("/add-customer")
    public ResponseEntity<Object> addCostumer(@RequestBody ClienteModel cliente) {
        boolean status = clienteService.addCostumer(cliente);

        if(status) {
            return ResponseEntity.ok().body(cliente);
        }
        return ResponseEntity.badRequest().body(new Erro("Erro inserir", "Email duplicado, ou erro no banco"));
    }
}

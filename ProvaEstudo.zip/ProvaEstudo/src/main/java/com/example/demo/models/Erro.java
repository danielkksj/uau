package com.example.demo.models;


public record Erro(String title, String message) {
}

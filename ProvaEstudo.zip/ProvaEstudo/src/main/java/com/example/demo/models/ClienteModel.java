package com.example.demo.models;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "customers")
public class ClienteModel {

    @Id
    @SerializedName("_id")
    private Object _id;

    @JsonProperty("Id")
    @SerializedName("Id")
    private int id;

    @JsonProperty("First Name")
    @SerializedName("First Name")
    private String firstName;

    @JsonProperty("Last Name")
    @SerializedName("Last Name")
    private String lastName;

    @JsonProperty("Company")
    @SerializedName("Company")
    private String company;

    @JsonProperty("City")
    @SerializedName("City")
    private String city;

    @JsonProperty("Country")
    @SerializedName("Country")
    private String country;

    @JsonProperty("Email")
    @SerializedName("Email")
    private String email;

    @JsonProperty("Website")
    @SerializedName("Website")
    private String website;

        public ClienteModel() {
        }

        public ClienteModel(String firstName, String lastName, String company, String city, String country, String email, String website) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.company = company;
            this.city = city;
            this.country = country;
            this.email = email;
            this.website = website;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getCompany() {
            return company;
        }

        public void setCompany(String company) {
            this.company = company;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getWebsite() {
            return website;
        }

        public void setWebsite(String website) {
            this.website = website;
        }

}

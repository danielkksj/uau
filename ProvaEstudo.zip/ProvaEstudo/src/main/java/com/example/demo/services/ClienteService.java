package com.example.demo.services;


import com.example.demo.models.ClienteModel;
import com.google.gson.Gson;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import static com.mongodb.client.model.Filters.eq;

@Service
public class ClienteService {

    public MongoDatabase getDataBase() {
        String connectionString = "mongodb://localhost:27017";
        MongoClient mongoClient = MongoClients.create(connectionString);
        MongoDatabase mongoDatabase = mongoClient.getDatabase("customers_collection");
        return mongoDatabase;
    }

    public boolean testaConexao() {
        try {
            MongoDatabase mongoDatabase = getDataBase();
            mongoDatabase.runCommand(new Document("ping", 1));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<ClienteModel> findByPais(String pais) {
        List<ClienteModel> clienteModels = new ArrayList<>();
        MongoDatabase mongoDatabase = getDataBase();
        MongoCollection<org.bson.Document> collection = mongoDatabase.getCollection("customers");
        MongoCursor<org.bson.Document> cursor = collection.find(eq("Country", pais)).iterator();

        Gson gson = new Gson();

        while(cursor.hasNext()) {
            org.bson.Document doc = cursor.next();
            clienteModels.add(gson.fromJson(doc.toJson(), ClienteModel.class));
        }
        cursor.close();

        return clienteModels;
    }

    public ClienteModel findById(int id) {
        MongoDatabase mongoDatabase = getDataBase();
        MongoCollection<org.bson.Document> collection = mongoDatabase.getCollection("customers");
        MongoCursor<Document> cursor = collection.find(eq("Id", id)).iterator();

        Gson gson = new Gson();

        if(cursor.hasNext())
            return gson.fromJson(cursor.next().toJson(), ClienteModel.class);
        return null;
    }

    public List<ClienteModel> findByName(String name) {
        MongoDatabase database = getDataBase();
        MongoCollection<Document> collection = database.getCollection("customers");
        List<ClienteModel> clienteModels = new ArrayList<>();

        Bson filtro = Filters.or(
                Filters.eq("First Name", name),
                Filters.eq("Last Name", name)
        );

        MongoCursor<Document> cursor = collection.find(filtro).iterator();

        Gson gson = new Gson();

        while(cursor.hasNext()) {
            Document doc = cursor.next();
            clienteModels.add(gson.fromJson(doc.toJson(), ClienteModel.class));
        }
        return clienteModels;
    }

    public List<String> listarPaisesEmOrdem() {
        MongoDatabase mongoDatabase = getDataBase();
        MongoCollection<org.bson.Document> collection = mongoDatabase.getCollection("customers");

        List<String> paises = new ArrayList<>();

        // 1. Busca os países sem repetição usando o .distinct()
        MongoCursor<String> cursor = collection.distinct("Country", String.class).iterator();

        try {
            while(cursor.hasNext()) {
                String pais = cursor.next();
                if (pais != null && !pais.trim().isEmpty()) {
                    paises.add(pais);
                }
            }
        } finally {
            cursor.close();
        }

        Collections.sort(paises);

        return paises;
    }

    public boolean addCostumer(ClienteModel cliente) {

        Gson gson = new Gson();
        MongoDatabase database= getDataBase();
        MongoCollection<Document> collection = database.getCollection("customers");
        org.bson.Document clienteExistente = collection.find(eq("Email", cliente.getEmail())).first();

        if(clienteExistente != null)
            return false;


        Document doc = Document.parse(gson.toJson(cliente));
        collection.insertOne(doc);
        return true;
    }
}
